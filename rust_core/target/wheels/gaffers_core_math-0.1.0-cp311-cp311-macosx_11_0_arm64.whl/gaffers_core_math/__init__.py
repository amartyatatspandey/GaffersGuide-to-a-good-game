from .gaffers_core_math import *

__doc__ = gaffers_core_math.__doc__
if hasattr(gaffers_core_math, "__all__"):
    __all__ = gaffers_core_math.__all__